import os
import requests
import urllib.request
import zipfile

hostx= input("Enter addres: ")
portx= input("Enter port: ")

server_url = f"http://{hostx}:{portx}"

def download_package(package_name):

    response = requests.get(f"{server_url}/files")

    if response.status_code != 200:
        print(f"Error accessing the server. Status code: {response.status_code}")
        return

    try:
        files_data = response.json()
    except requests.exceptions.JSONDecodeError as e:
        print(f"Error decoding JSON response from the server: {e}")
        return

    package_found = False

    for file_info in files_data:
        if file_info["name"] == package_name:
            package_found = True
            package_url = f"{server_url}/download/{urllib.request.quote(package_name)}"
            break

    if not package_found:
        print(f"Package '{package_name}' not found on the server.")
        return

    if not os.path.exists("FMI manager"):
        os.makedirs("FMI manager")

    download_path = os.path.join("FMI manager", package_name)
    urllib.request.urlretrieve(package_url, download_path)
    print(f"Package '{package_name}' downloaded successfully.")

    if package_name.lower().endswith(".zip"):
        uza =  input("Did You wont to extracted zip file [Y/N]: ")
        if uza == "yes" or "y":
            extract_path = os.path.join("FMI manager", package_name[:-4])
            with zipfile.ZipFile(download_path, "r") as zip_ref:
                zip_ref.extractall(extract_path)
            print(f"Package '{package_name}' extracted successfully.")

def main():
    package_name = input("Enter the package name you want to download: ")
    download_package(package_name)

if __name__ == "__main__":
    main()
